
 import scala.collection.mutable.ListBuffer

object Lab5 {
   def main(args: Array[String]):Unit={
     println("Enter the number you want to find prime numbers till: ")
     val n=scala.io.StdIn.readInt()

     val x=List.range(1, n+1)
     
     println("List before removing composite numbers is: ")
    println(x)
     val p=2
     val sq=scala.math.sqrt(n)
     
     val x1 = sieve(x, p, sq, n)
     println("The prime numbers list is: ")
     println(x1)
     
   }
   
   def sieve(x:List[Int], p:Int, sq:Double, n:Int ): List[Int]={
     
     if(p>sq)
     {
      return x 
     }
     
     val list = x.filter(a => !(a % p == 0 && a != p))
       sieve(list, p + 1,sq, n)
       
          
   }
  
}