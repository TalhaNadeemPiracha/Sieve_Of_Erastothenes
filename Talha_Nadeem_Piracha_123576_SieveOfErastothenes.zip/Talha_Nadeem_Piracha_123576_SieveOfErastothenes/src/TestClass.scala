import org.junit.Test
import junit.framework.Assert

class TestClass {
  
  @Test
  def testSieve(){
    
    val expectedList = List(1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47)
    val actualList = Lab5.sieve(List.range(1, 50 + 1), 2, scala.math.sqrt(50), 50)
    Assert.assertEquals(expectedList, actualList)
    
    val expectedList2 = List(1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97)
    val actualList2 = Lab5.sieve(List.range(1, 100 + 1), 2, scala.math.sqrt(100), 100)
    Assert.assertEquals(expectedList2, actualList2)
        
  
  }
}